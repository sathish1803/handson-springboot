package com.example.springbootswagger2.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "sathish")
public class ActuatorConfiguration {
    String port;

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    ActuatorConfiguration() {
        System.out.println("port:::" +port);
    }
}
