package com.testspring.testrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
