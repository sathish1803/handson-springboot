package com.testspring.testrest;

import java.util.Arrays;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class TestRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestRestApplication.class, args);
	}

	@Bean
    public CommandLineRunner run(ApplicationContext appContext) {
        return args -> {
            String[] beans = appContext.getBeanDefinitionNames();
            Arrays.stream(beans).sorted().forEach(System.out::println);
        };
    }
	
	@Bean
	public ResourceConfig register() {
		return new ResourceConfig().packages("com.testspring.testrest"); 
	}
}
