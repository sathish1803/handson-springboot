package com.testspring.testrest.controller;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

import org.springframework.web.bind.annotation.RestController;

@RestController
@Path("/v1/testRestController")
public class TestRestController {

	@GET
	@Path("/testMethod")
	public void testMethod() {
		System.out.println("Sdfdsfsdfsdfd::::");
	}
	
}
