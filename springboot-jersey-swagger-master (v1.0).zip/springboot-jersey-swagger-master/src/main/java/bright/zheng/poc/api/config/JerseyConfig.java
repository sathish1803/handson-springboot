package bright.zheng.poc.api.config;

import io.swagger.jaxrs.config.BeanConfig;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class JerseyConfig extends ResourceConfig {

	@Value("${spring.jersey.application-path:/api}")
	private String apiPath;

	public JerseyConfig() {
		this.registerEndpoints();
	}
	
	@PostConstruct
	public void init() {
		this.configureSwagger();
	}

	private void registerEndpoints() {
		this.packages("bright.zheng.poc.api.service");
	}

	private void configureSwagger() {
		this.packages("io.swagger.jaxrs.listing");

		BeanConfig config = new BeanConfig();
		config.setTitle("POC - Restful API by Spring Boot, Jersey, Swagger");
		config.setVersion("v1");
		config.setContact("Bright Zheng");
		config.setSchemes(new String[] { "http", "https" });
		config.setBasePath(this.apiPath);
		config.setResourcePackage("bright.zheng.poc.api.service");
		config.setPrettyPrint(true);
		config.setScan(true);
	}

}
